#!/bin/sh
./main $1 | grep "NEXT-INSTRUCTION"
