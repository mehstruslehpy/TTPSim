#include "../common.h"
#include "Ram.h"

using namespace std;
int main()
{
    Ram testRam;
    cout << "hello world" << endl;
    return 0;
}
